import { Component } from '@angular/core';
import { HttpService } from '../../shared/http.service';

@Component({
  selector: 'app-allproducts',
  standalone: false,
  templateUrl: './allproducts.component.html',
  styleUrl: './allproducts.component.css'
})
export class AllproductsComponent {


  products:any;
  constructor(private service:HttpService){
    this.getAllProduct();   
  }

  getAllProduct(){
    this.service.getAllProducts().subscribe((data:any) =>{
      this.products = data
      console.log(this.products);      
    })
  }

}
