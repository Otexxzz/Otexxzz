import { Component } from '@angular/core';
import { HttpService } from '../../service/http.service';

@Component({
  selector: 'app-basket',
  standalone: false,
  templateUrl: './basket.component.html',
  styleUrl: './basket.component.css'
})
export class BasketComponent {


  products:any;
constructor(private service:HttpService){
this.getBasketProduct()
}

getBasketProduct(){
  this.service.getBasket().subscribe((data:any) =>{
this.products = data;
console.log(this.products);

  })
};

deleteProduct(id:number){
console.log(id);
this.service.getDeleteProduct(id).subscribe(
  (response)=>{
    alert('deleted');
    this.getBasketProduct();
  },
  (error)=>{
    console.error(error);
  }
)
};

incrementQuantity(product:any){

  let newQuantity = product.quantity;
  newQuantity ++;
  let newPrice = newQuantity * product.product.price;

  const putProduct = {
    quantity: newQuantity,
    price: newPrice,
    productId:product.product.id
  };

  this.service.getPutProduct(putProduct).subscribe(
    (response) =>{
     this.getBasketProduct();
    },
    (error)=>{
      console.log(error);
      
    }
  )
};


decrementProduct(product:any){

  if(product.quantity > 1){
    let newQuantity = product.quantity;
newQuantity --;

let newPrice = newQuantity * product.product.price;
  const putProduct = {
    quantity: newQuantity,
    price: newPrice,
    productId:product.product.id
  };
  this.service.getPutProduct(putProduct).subscribe(
    (response) =>{
      this.getBasketProduct()
    },
    (error) =>{
      console.log(error);
      
    }
  )


  }else{

   let answer = confirm('are you sure?');
   console.log(answer);

if(answer){
  this.service.getDeleteProduct(product.product.id).subscribe(
    (response) =>{
      this.getBasketProduct()
    },
    (error)=>{
      console.log(error);
      
    }
  )
}
}
}
   
   

}
