import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpService } from '../../service/http.service';

@Component({
  selector: 'app-categoryproducts',
  standalone: false,
  templateUrl: './categoryproducts.component.html',
  styleUrl: './categoryproducts.component.css'
})
export class CategoryproductsComponent {

  id!:number;
  products:any;
  constructor(private route:ActivatedRoute, private service:HttpService){
this.getId();
this.getProducts();
  }

  getId(){
    this.route.params.subscribe((el:any) =>{
      this.id = el.id;
      console.log(this.id);  
    })
  }
  getProducts(){
    this.service.getProductsOfCategory(this.id).subscribe((data:any) =>{
      
      this.products = data;
    
      
    }) 
  };


  postProduct(product:any){
console.log(product);

const newProduct ={
  quantity:1,
  price: product.price,
  productId: product.id,
};

this.service.getPostProduct(newProduct).subscribe(
  (response) =>{
    alert('product added')
  },
  (error) =>{
    console.error(error);
    
  }
)

  }

      

     
  

}
