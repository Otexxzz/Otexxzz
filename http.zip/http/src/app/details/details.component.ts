import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-details',
  standalone: false,
  templateUrl: './details.component.html',
  styleUrl: './details.component.css'
})
export class DetailsComponent {

  product:any;

  constructor(private route:ActivatedRoute, private location:Location){
    this.route.queryParams.subscribe((data:any) =>{
      this.product = data;
      console.log(this.product);
      
    })
  }

  goBack(){
this.location.back();
  }

}
