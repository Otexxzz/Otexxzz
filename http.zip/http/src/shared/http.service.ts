import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private http:HttpClient) { }

  _ALLPRODUCTS_URL:string = "https://restaurant.stepprojects.ge/api/Products/GetAll";
  _CATEGORY_URL:string = "https://restaurant.stepprojects.ge/api/Categories/GetAll";
  _PRODUCTSFROMCATEGORY_URL:string = "https://restaurant.stepprojects.ge/api/Categories/GetCategory"
  _BSKET_URL:string = "https://restaurant.stepprojects.ge/api/Baskets/GetAll";

  getAllProducts():Observable<any>{
  return this.http.get(this._ALLPRODUCTS_URL)
};

getCategory():Observable<any>{
  return this.http.get(this._CATEGORY_URL);
};

getCategoryProduct(id:any):Observable<any>{
  return this.http.get(`${this._PRODUCTSFROMCATEGORY_URL}/${id}`);
};
getBasket():Observable<any>{
 return this.http.get(this._BSKET_URL);
}

}
